# FileTemplates
Just a shortcut template for files

Press Ctrl + Shift + N to make a new file with .html extension with a basic HTML template

Press Ctrl + P to make a new file with .php extension with a basic PHP template

Press Ctrl + Shift + V to make a new file with .html extension with a basic Vue.js template

Press Ctrl + Shift + A to make a new file with .html extension with a basic AJAX template

# How to install

## First choice:

1. You need to have Brackets

1. Open Brackets and go to the Extension Manager 

1. Search "New File Templates"

1. Install that extension

1. You are able to use the shortcut functions

## Second choice:

1. Download the zip folder from the Releases Page

1. Extract that folder

1. Copy that file into the Extensions folder in your Brackets installation directory

1. After that you will be able to use that shortcut function. 




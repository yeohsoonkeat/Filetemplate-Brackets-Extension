<?php
    $q = $_REQUEST['q'];
    echo "$q";
?>